Click README.md above to: edit, rename, download, or delete me.<br>
Click on issues to create an issue.<br>
Click on settings to manage settings.<br>
Deleted files/folders will go to the trash tab.<br>