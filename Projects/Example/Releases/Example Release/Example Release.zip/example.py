def main():
    print('Example!')


main()